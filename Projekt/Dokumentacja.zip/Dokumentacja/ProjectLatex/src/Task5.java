public void pokazprodukty() {
    try {
        UserDAO userDAO = new UserDAO();
        List<Produkt> produkty = userDAO.pokazProdukty();
        ObservableList<Produkt> produkts = FXCollections.observableArrayList(produkty);
        widok.setItems(produkts);
        widok.setEditable(true);
        zaznaczField.setEditable(true);
        zaznaczField.setCellValueFactory(new PropertyValueFactory<>("zaznaczony"));
        zaznaczField.setCellFactory(CheckBoxTableCell.forTableColumn(zaznaczField));
        nazwaproduktuField.setCellValueFactory(new PropertyValueFactory<>("nazwa"));
        iloscproduktuField.setCellValueFactory(new PropertyValueFactory<>("ilosc"));
        cenaproduktuField.setCellValueFactory(new PropertyValueFactory<>("cena"));
        opisproduktuField.setCellValueFactory(new PropertyValueFactory<>("opis"));
    } catch (SQLException e) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setHeaderText(null);
        alert.setContentText("Ladowanie produktow nie powiodlo sie!");
        alert.showAndWait();
    }
}