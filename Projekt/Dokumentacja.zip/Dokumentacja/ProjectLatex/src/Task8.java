public void usunprodukt(int id_produktu) throws SQLException {
    String sql = "DELETE FROM produkty WHERE id_produktu = ?";
    try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(s
            pstmt.setInt(1, id_produktu);
         pstmt.executeUpdate();
}
}