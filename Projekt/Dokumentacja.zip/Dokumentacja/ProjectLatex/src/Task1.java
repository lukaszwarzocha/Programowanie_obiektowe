protected void Login() {
    String loginuzytkownika = loginField.getText();
    String login = loginField.getText();
    String password = passwordField.getText();
    if (login.isEmpty() || password.isEmpty()) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setHeaderText(null);
        alert.setContentText("Musisz wypelnic wszystkie pola!");
        alert.showAndWait();
        return;
    }
    try {
        UserDAO userDAO = new UserDAO();
        if (userDAO.ZalogujAdministrator(login, password)) {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("adminpanel.fxml"));
            logowanie(fxmlLoader);
            AdminPanelController adminpanel = fxmlLoader.getController();
            adminpanel.wyswietlogin(loginuzytkownika);
        } else if (userDAO.ZalogujUzytkownik(login, password)) {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("userpanel.fxml"));
            logowanie(fxmlLoader);
            UserPanelController userpanel = fxmlLoader.getController();
            userpanel.wyswietlogin(loginuzytkownika);
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setContentText("Podales nieprawidlowy login lub haslo!");
            alert.showAndWait();
        }
    } catch (Exception e) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setHeaderText(null);
        alert.setContentText("Blad podczas logowania!");
        alert.showAndWait();
    }
}
