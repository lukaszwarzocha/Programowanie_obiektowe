public void dodajzamowienie(int id_klienta, Date data_zamowienia, String status_zamowienia, double cena_zamowienia) throws SQLException {
    String sql = "INSERT INTO public.zamowienia(id_klienta, data_zamowienia, status_zamowienia, cena_zamowienia) VALUES (?,?,?,?)";
    try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setInt(1, id_klienta);
        pstmt.setDate(2, data_zamowienia);
        pstmt.setString(3, status_zamowienia);
        pstmt.setDouble(4, cena_zamowienia);
        pstmt.executeUpdate();
    }
}