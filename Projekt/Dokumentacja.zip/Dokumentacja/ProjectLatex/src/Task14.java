public void zakup(String login, double kwota) throws SQLException {
    String sql = "UPDATE klienci SET saldo = saldo - ? WHERE login = ?";
    try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setDouble(1, kwota);
        pstmt.setString(2, login);
        pstmt.executeUpdate();
    }
}