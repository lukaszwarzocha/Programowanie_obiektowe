public void wplacsrodki() {
    String wplata = wplataField.getText();
    double wplata2;
    try {
        wplata2 = Double.parseDouble(wplata);
        if (wplata2 <= 1) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText(null);
            alert.setContentText("Musisz wplacic minimum 1 PLN!");
            alert.showAndWait();
            return;
        }
        UserDAO userDAO = new UserDAO();
        userDAO.depozyt(loginuzytkownika, wplata2);
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setHeaderText(null);
        alert.setContentText("Wplata udana!");
        alert.showAndWait();
        wyswietlsaldo();
        wplataField.clear();
        ukryjpanel();
    } catch (SQLException e) {
        throw new RuntimeException(e);
    } catch (NumberFormatException e) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setHeaderText(null);
        alert.setContentText("Zly format kwoty!");
        alert.showAndWait();
    }
}