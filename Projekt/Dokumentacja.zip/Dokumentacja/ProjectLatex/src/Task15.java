public void szukanieproduktow() {
    UserDAO userDAO = new UserDAO();
    String filtrowanie = szukanieField.getText();
    try {
        List<Produkt> wyniki = userDAO.szukajProdukt(filtrowanie);
        ObservableList<Produkt> produkts = FXCollections.observableArrayList(wyniki);
        for (Produkt p : produkts) {
            p.setZaznaczony(zaznaczoneProdukty.contains(p.getId_produktu()));
        }
        widok.setItems(produkts);
        ListenerDoZaznaczen(produkts);
    } catch (SQLException e) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setHeaderText(null);
        alert.setContentText("Blad przy filtrowaniu produktow!");
        alert.showAndWait();
    }
}