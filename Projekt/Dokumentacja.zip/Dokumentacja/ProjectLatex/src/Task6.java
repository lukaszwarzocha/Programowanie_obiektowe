public List<Produkt> pokazProdukty() throws SQLException {
    List<Produkt> produkty = new ArrayList<>();
    String sql = "SELECT * FROM produkty";
    try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareState
ResultSet rs = pstmt.executeQuery();
    while (rs.next()) {
        int id = rs.getInt("id_produktu");
        String nazwa = rs.getString("nazwa");
        double cena = rs.getDouble("cena");
        Integer ilosc = rs.getInt("ilosc");
        String opis = rs.getString("opis");
        Produkt produkt = new Produkt(id, nazwa, cena, ilosc, opis);
        produkty.add(produkt);
    }
}
return produkty;
}