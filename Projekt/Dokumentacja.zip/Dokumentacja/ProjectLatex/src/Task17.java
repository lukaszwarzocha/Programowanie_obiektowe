private void ListenerDoZaznaczen(ObservableList<Produkt> produkty) {
    for (Produkt produkt : produkty) {
        produkt.zaznaczonyProperty().addListener(
                (obs, oldVal, newVal) -> {
                    if (newVal) {
                        zaznaczoneProdukty.add(produkt.getId_produktu());
                    } else {
                        zaznaczoneProdukty.remove(produkt.getId_produktu());
                    }
                }
        );
    }
}