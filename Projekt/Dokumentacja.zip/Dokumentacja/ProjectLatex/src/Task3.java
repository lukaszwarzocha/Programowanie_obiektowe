public void dodaj() {
    String nazwa = nazwaField.getText();
    String cenaText = cenaField.getText();
    String iloscText = iloscField.getText();
    String opis = opisField.getText();
    if (nazwa.isEmpty() || cenaText.isEmpty() || iloscText.isEmpty()) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setHeaderText(null);
        alert.setContentText("Uzupelnij pola!");
        alert.showAndWait();
        return;
    }
    int ilosc;
    ilosc = Integer.parseInt(iloscText);
    if (ilosc < 1) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setHeaderText(null);
        alert.setContentText("Musisz wystawic minimum jeden produkt!");
        alert.showAndWait();
        return;
    }
    try {
        UserDAO userDAO = new UserDAO();
        double cena = Double.parseDouble(cenaText.replaceAll(",", "."));
        int ilosc2 = Integer.parseInt(iloscText);
        userDAO.dodajProdukt(nazwa, cena, ilosc2, opis);
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setHeaderText(null);
        alert.setContentText("Dodales produkt!");
        alert.showAndWait();
        wyczysc();
        ukryjpanel();
    } catch (SQLException e) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setHeaderText(null);
        alert.setContentText("Blad dodawania produktu!");
        alert.showAndWait();
    } catch (NumberFormatException e) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setHeaderText(null);
        alert.setContentText("Cena musi byc liczba!");
        alert.showAndWait();
    }
}