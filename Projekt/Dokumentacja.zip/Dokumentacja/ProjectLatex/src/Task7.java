public void usunprodukt() {
    ObservableList<Produkt> zazprodukty = FXCollections.observableArrayList();
    for (Produkt produkt : widok.getItems()) {
        if (produkt.isZaznaczony()) {
            zazprodukty.add(produkt);
        }
    }
    if (zazprodukty.isEmpty()) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setHeaderText(null);
        alert.setContentText("Pierw zaznacz produkt ktory chcesz usunac!");
        alert.showAndWait();
        return;
    }
    try {
        UserDAO userDAO = new UserDAO();
        for (Produkt produkt : zazprodukty) {
            userDAO.usunprodukt(produkt.getId_produktu());
        }
        widok.getItems().removeAll(zazprodukty);
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setHeaderText(null);
        alert.setContentText("Zaznaczone produkty zostaly usuniete!");
        alert.showAndWait();
    } catch (SQLException e) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setHeaderText(null);
        alert.setContentText("Blad przy usuwaniu produktow!");
        alert.showAndWait();
    }
}