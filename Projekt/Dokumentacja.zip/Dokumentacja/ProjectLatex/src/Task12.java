public void zakup() {
    ObservableList<Produkt> produktydozakupu = widokkoszyka.getItems();
    if (produktydozakupu.isEmpty()) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setHeaderText(null);
        alert.setContentText("Twoj koszyk jest pusty!");
        alert.showAndWait();
        return;
    }
    double cenacalkowita = 0;
    for (Produkt produkt : produktydozakupu) {
        cenacalkowita += produkt.getCena() * produkt.getIloscdozakupu();
    }
    try {
        UserDAO userDAO = new UserDAO();
        double saldo = userDAO.Wyswietlsaldo(loginuzytkownika);
        if (saldo < cenacalkowita) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText(null);
            alert.setContentText("Brak wystarczajacych srodkow na koncie!!");
            alert.showAndWait();
            return;
        }
        int id_klienta = userDAO.znajdzuzytkownikapologinie(loginuzytkownika);
        Date dzis = new Date(System.currentTimeMillis());
        userDAO.dodajzamowienie(id_klienta, dzis, "W REALIZACJI", cenacalkowita);
        userDAO.zakup(loginuzytkownika, cenacalkowita);
        for (Produkt produkt : produktydozakupu) {
            if (produkt.getIloscdozakupu() == produkt.getIlosc()) {
                userDAO.usunprodukt(produkt.getId_produktu());
            } else {
                int nowailoscproduktu = produkt.getIlosc() - produkt.getIloscdozakupu();
                userDAO.zaaktualizujiloscproduktu(produkt.getId_produktu(), nowailoscproduktu);
            }
        }
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setHeaderText(null);
        alert.setContentText("Zakup udany!");
        alert.showAndWait();
        wyswietlsaldo();
        pokazprodukty();
        widokkoszyka.getItems().clear();
        cenacalkowitaField.clear();
        ukryjpanel();
    } catch (SQLException e) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setHeaderText(null);
        alert.setContentText("Problem z zakupem!");
        alert.showAndWait();
    }
}