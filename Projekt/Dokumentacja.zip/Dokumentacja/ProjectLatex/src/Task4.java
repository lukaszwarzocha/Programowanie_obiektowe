public void dodajProdukt(String nazwa, double cena, Integer ilosc, String opis) throws SQLException {
    String sql = "INSERT INTO produkty (nazwa,cena,ilosc,opis) VALUES (?,?,?,?)";
    try (Connection conn = DBConnection.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setString(1, nazwa);
        pstmt.setDouble(2, cena);
        pstmt.setInt(3, ilosc);
        pstmt.setString(4, opis);
        pstmt.executeUpdate();
    }
}