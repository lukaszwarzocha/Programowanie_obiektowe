public void depozyt(String login, double amount) throws SQLException {
    String sql = "UPDATE klienci SET saldo = saldo + ? WHERE login = ?";
    try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareState
pstmt.setDouble(1, amount);
    pstmt.setString(2, login);
    pstmt.executeUpdate();
}
}