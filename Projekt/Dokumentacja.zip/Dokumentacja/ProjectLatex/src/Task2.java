public boolean ZalogujUzytkownik(String login, String haslo) throws SQLException {
    String sql = "SELECT * FROM klienci WHERE login = ? AND haslo = ? AND rola = 'UZYTKOWNIK'";
    try (Connection conn = DBConnection.getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setString(1, login);
        stmt.setString(2, haslo);
        ResultSet rs = stmt.executeQuery();
        return rs.next();
    }
}
public boolean ZalogujAdministrator(String login, String haslo) throws SQLException {
    String sql = "SELECT * FROM klienci WHERE login = ? AND haslo = ? AND rola = 'ADMINISTRATOR'";
    try (Connection conn = DBConnection.getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setString(1, login);
        stmt.setString(2, haslo);
        ResultSet rs = stmt.executeQuery();
        return rs.next();
    }
}