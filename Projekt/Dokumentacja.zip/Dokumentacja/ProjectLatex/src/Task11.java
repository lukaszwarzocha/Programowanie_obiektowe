public void wyswietlkoszyk() {
    ObservableList<Produkt> produktykoszyk = Wyswietlprodukty();
    koszykiloscproduktudozakupuField.setCellValueFactory(new PropertyValueFactory<>("iloscdozakupu"));
    koszyknazwaproduktuField.setCellValueFactory(new PropertyValueFactory<>("nazwa"));
    koszykcenaproduktuField.setCellValueFactory(new PropertyValueFactory<>("cena"));
    koszykiloscproduktuField.setCellValueFactory(new PropertyValueFactory<>("ilosc"));
    koszykiloscproduktudozakupuField.setCellFactory(TextFieldTableCell.forTableColumn(new IntegerStringCon
            koszykiloscproduktudozakupuField.setOnEditCommit(event -> {
                Produkt produkt = event.getRowValue();
                int newValue = event.getNewValue();
                if (produkt == null) {
                    return;
                }
                if (newValue < 1) {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setHeaderText(null);
                    alert.setContentText("Musisz zamowic minimum 1 sztuke tego produktu!");
                    alert.showAndWait();
                    widokkoszyka.refresh();
                    return;
                }
                if (newValue > produkt.getIlosc()) {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setHeaderText(null);
                    alert.setContentText("Nie mozesz zamowic wiecej niz dostepna ilosc!");
                    alert.showAndWait();
                    widokkoszyka.refresh();
                    return;
                }
                produkt.setIloscdozakupu(newValue);
                zaaktualizujcene();
                widokkoszyka.refresh();
            });
    widokkoszyka.setEditable(true);
    widokkoszyka.setItems(produktykoszyk);
    zaaktualizujcene();
    pokazpanel(dodajpanel4);
}