--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4
-- Dumped by pg_dump version 17.2

-- Started on 2025-06-15 20:12:59

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 851 (class 1247 OID 32815)
-- Name: rola_typ; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.rola_typ AS ENUM (
    'ADMINISTRATOR',
    'UZYTKOWNIK'
);


ALTER TYPE public.rola_typ OWNER TO postgres;

--
-- TOC entry 857 (class 1247 OID 32826)
-- Name: status_zamowienia_typ; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.status_zamowienia_typ AS ENUM (
    'W REALIZACJI',
    'WYSLANE',
    'ANULOWANE'
);


ALTER TYPE public.status_zamowienia_typ OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 218 (class 1259 OID 49259)
-- Name: klienci; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.klienci (
    id_klienta integer NOT NULL,
    login character varying(100) NOT NULL,
    haslo character varying(100) NOT NULL,
    imie character varying(50) NOT NULL,
    nazwisko character varying(50) NOT NULL,
    wiek integer NOT NULL,
    email character varying(100) NOT NULL,
    adres character varying(100) NOT NULL,
    rola character varying(20) DEFAULT 'UZYTKOWNIK'::character varying,
    saldo numeric(10,2) DEFAULT 0,
    CONSTRAINT klienci_rola_check CHECK (((rola)::text = ANY ((ARRAY['ADMINISTRATOR'::character varying, 'UZYTKOWNIK'::character varying])::text[]))),
    CONSTRAINT klienci_wiek_check CHECK ((wiek >= 18))
);


ALTER TABLE public.klienci OWNER TO postgres;

--
-- TOC entry 217 (class 1259 OID 49258)
-- Name: klienci_id_klienta_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.klienci_id_klienta_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.klienci_id_klienta_seq OWNER TO postgres;

--
-- TOC entry 4849 (class 0 OID 0)
-- Dependencies: 217
-- Name: klienci_id_klienta_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.klienci_id_klienta_seq OWNED BY public.klienci.id_klienta;


--
-- TOC entry 220 (class 1259 OID 49276)
-- Name: produkty; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.produkty (
    id_produktu integer NOT NULL,
    nazwa character varying(100) NOT NULL,
    cena numeric(10,2) NOT NULL,
    ilosc integer DEFAULT 0 NOT NULL,
    opis text,
    CONSTRAINT produkty_cena_check CHECK ((cena > (0)::numeric))
);


ALTER TABLE public.produkty OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 49275)
-- Name: produkty_id_produktu_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.produkty_id_produktu_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.produkty_id_produktu_seq OWNER TO postgres;

--
-- TOC entry 4850 (class 0 OID 0)
-- Dependencies: 219
-- Name: produkty_id_produktu_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.produkty_id_produktu_seq OWNED BY public.produkty.id_produktu;


--
-- TOC entry 222 (class 1259 OID 49287)
-- Name: zamowienia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.zamowienia (
    id_zamowienia integer NOT NULL,
    id_klienta integer NOT NULL,
    data_zamowienia timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    status_zamowienia character varying(20) DEFAULT 'W REALIZACJI'::character varying,
    cena_zamowienia numeric(10,2) NOT NULL,
    CONSTRAINT zamowienia_cena_zamowienia_check CHECK ((cena_zamowienia > (0)::numeric)),
    CONSTRAINT zamowienia_status_zamowienia_check CHECK (((status_zamowienia)::text = ANY ((ARRAY['W REALIZACJI'::character varying, 'WYSLANE'::character varying, 'ANULOWANE'::character varying])::text[])))
);


ALTER TABLE public.zamowienia OWNER TO postgres;

--
-- TOC entry 221 (class 1259 OID 49286)
-- Name: zamowienia_id_zamowienia_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.zamowienia_id_zamowienia_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.zamowienia_id_zamowienia_seq OWNER TO postgres;

--
-- TOC entry 4851 (class 0 OID 0)
-- Dependencies: 221
-- Name: zamowienia_id_zamowienia_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.zamowienia_id_zamowienia_seq OWNED BY public.zamowienia.id_zamowienia;


--
-- TOC entry 4669 (class 2604 OID 49262)
-- Name: klienci id_klienta; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.klienci ALTER COLUMN id_klienta SET DEFAULT nextval('public.klienci_id_klienta_seq'::regclass);


--
-- TOC entry 4672 (class 2604 OID 49279)
-- Name: produkty id_produktu; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produkty ALTER COLUMN id_produktu SET DEFAULT nextval('public.produkty_id_produktu_seq'::regclass);


--
-- TOC entry 4674 (class 2604 OID 49290)
-- Name: zamowienia id_zamowienia; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.zamowienia ALTER COLUMN id_zamowienia SET DEFAULT nextval('public.zamowienia_id_zamowienia_seq'::regclass);


--
-- TOC entry 4839 (class 0 OID 49259)
-- Dependencies: 218
-- Data for Name: klienci; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.klienci VALUES (1, 'lukwar20', 'lukasz', 'Lukasz', 'Warzocha', 21, 'lukasz@gmail.com', 'Wilczyce 80', 'ADMINISTRATOR', 2000.00);
INSERT INTO public.klienci VALUES (3, 'pjaki', 'patryk', 'Patryk', 'Jaki', 30, 'pjaki@example.com', 'Warszawa, ul. Sejmowa 1', 'UZYTKOWNIK', 150.00);
INSERT INTO public.klienci VALUES (4, 'akowalska', 'anna', 'Anna', 'Kowalska', 28, 'akowalska@example.com', 'Kraków, ul. Długa 12', 'UZYTKOWNIK', 220.00);
INSERT INTO public.klienci VALUES (5, 'mjankowski', 'mateusz', 'Mateusz', 'Jankowski', 35, 'mjankowski@example.com', 'Gdańsk, ul. Morska 5', 'UZYTKOWNIK', 85.50);
INSERT INTO public.klienci VALUES (6, 'kzielinski', 'kamil', 'Kamil', 'Zieliński', 40, 'kzielinski@example.com', 'Poznań, ul. Lecha 7', 'UZYTKOWNIK', 300.00);
INSERT INTO public.klienci VALUES (7, 'dnowak', 'daria', 'Daria', 'Nowak', 26, 'dnowak@example.com', 'Wrocław, ul. Ratuszowa 3', 'UZYTKOWNIK', 120.00);
INSERT INTO public.klienci VALUES (2, 'michal25', 'michal', 'Michal', 'Kowalski', 25, 'michal@gmail.com', 'Radoszki 25', 'UZYTKOWNIK', 699.97);


--
-- TOC entry 4841 (class 0 OID 49276)
-- Dependencies: 220
-- Data for Name: produkty; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.produkty VALUES (10, 'Nawóz uniwersalny 5kg', 65.00, 22, 'Granulat do wszystkich roślin ogrodowych');
INSERT INTO public.produkty VALUES (12, 'Zraszacz obrotowy', 59.00, 10, 'Automatyczny zraszacz z trzema ramionami');
INSERT INTO public.produkty VALUES (14, 'Stół ogrodowy drewniany', 699.00, 3, 'Solidny stół do ogrodu, sosna impregnowana');
INSERT INTO public.produkty VALUES (15, 'Kosiarka spalinowa 1600W', 1299.00, 4, 'Kosiarka do trawy z napędem, silnik 1600W');
INSERT INTO public.produkty VALUES (16, 'Parasol ogrodowy 2,5m', 249.00, 6, 'Parasol przeciwsłoneczny z regulacją kąta');
INSERT INTO public.produkty VALUES (5, 'Sekator nożycowy', 54.99, 24, 'Sekator do cięcia gałęzi i krzewów');
INSERT INTO public.produkty VALUES (6, 'Rękawice ogrodowe', 14.99, 59, 'Oddychające rękawice ochronne, rozmiar uniwersalny');
INSERT INTO public.produkty VALUES (4, 'Grabie stalowe', 39.50, 16, 'Grabie do liści i trawy, metalowe z drewnianym trzonkiem');
INSERT INTO public.produkty VALUES (8, 'Pazurki ogrodowe', 21.00, 34, 'Narzędzie do spulchniania ziemi');
INSERT INTO public.produkty VALUES (7, 'Doniczka ceramiczna 25cm', 34.90, 39, 'Estetyczna doniczka do domu i ogrodu');
INSERT INTO public.produkty VALUES (13, 'Tunel foliowy 3x2m', 349.00, 4, 'Folia ogrodnicza na stelażu do uprawy warzyw');
INSERT INTO public.produkty VALUES (17, 'Eukaliptus', 249.99, 5, 'Roslina Eukaliptus');
INSERT INTO public.produkty VALUES (11, 'Wąż ogrodowy 20m', 89.90, 6, 'Elastyczny wąż ogrodowy, odporny na UV');


--
-- TOC entry 4843 (class 0 OID 49287)
-- Dependencies: 222
-- Data for Name: zamowienia; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.zamowienia VALUES (1, 2, '2025-06-07 00:00:00', 'W REALIZACJI', 649.75);
INSERT INTO public.zamowienia VALUES (2, 2, '2025-06-11 00:00:00', 'W REALIZACJI', 69.98);
INSERT INTO public.zamowienia VALUES (3, 2, '2025-06-11 00:00:00', 'W REALIZACJI', 179.00);
INSERT INTO public.zamowienia VALUES (4, 2, '2025-06-11 00:00:00', 'W REALIZACJI', 383.90);
INSERT INTO public.zamowienia VALUES (5, 2, '2025-06-14 00:00:00', 'W REALIZACJI', 539.40);


--
-- TOC entry 4852 (class 0 OID 0)
-- Dependencies: 217
-- Name: klienci_id_klienta_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.klienci_id_klienta_seq', 7, true);


--
-- TOC entry 4853 (class 0 OID 0)
-- Dependencies: 219
-- Name: produkty_id_produktu_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.produkty_id_produktu_seq', 17, true);


--
-- TOC entry 4854 (class 0 OID 0)
-- Dependencies: 221
-- Name: zamowienia_id_zamowienia_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.zamowienia_id_zamowienia_seq', 5, true);


--
-- TOC entry 4683 (class 2606 OID 49274)
-- Name: klienci klienci_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.klienci
    ADD CONSTRAINT klienci_email_key UNIQUE (email);


--
-- TOC entry 4685 (class 2606 OID 49272)
-- Name: klienci klienci_login_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.klienci
    ADD CONSTRAINT klienci_login_key UNIQUE (login);


--
-- TOC entry 4687 (class 2606 OID 49270)
-- Name: klienci klienci_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.klienci
    ADD CONSTRAINT klienci_pkey PRIMARY KEY (id_klienta);


--
-- TOC entry 4689 (class 2606 OID 49285)
-- Name: produkty produkty_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produkty
    ADD CONSTRAINT produkty_pkey PRIMARY KEY (id_produktu);


--
-- TOC entry 4691 (class 2606 OID 49296)
-- Name: zamowienia zamowienia_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.zamowienia
    ADD CONSTRAINT zamowienia_pkey PRIMARY KEY (id_zamowienia);


--
-- TOC entry 4692 (class 2606 OID 49297)
-- Name: zamowienia zamowienia_id_klienta_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.zamowienia
    ADD CONSTRAINT zamowienia_id_klienta_fkey FOREIGN KEY (id_klienta) REFERENCES public.klienci(id_klienta) ON UPDATE CASCADE ON DELETE CASCADE;


-- Completed on 2025-06-15 20:12:59

--
-- PostgreSQL database dump complete
--

